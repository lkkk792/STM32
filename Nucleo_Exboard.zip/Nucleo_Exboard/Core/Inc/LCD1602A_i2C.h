/*
 * LCD1602A_i2C.h
 *
 *  Created on: Nov 11, 2026
 *      Author: YOBRO
 */

#ifndef INC_LCD1602A_I2C_H_
#define INC_LCD1602A_I2C_H_

#include "stm32l0xx_hal.h"

#define LCD_ADDRESS 0x4E
#define LCD_BACKLIGHT 0x08						// bit3->0:OFF, 1:ON
#define LCD_ENABLE 0x04
#define LCD_RS 0x01								// bit0->0:cmd, 1:data

void Delay_us(uint32_t us);
void LCD_Send_4bits(uint8_t data, uint8_t rs);
void LCD_Send_cmd(uint8_t cmd);
void LCD_Send_data(uint8_t data);
void LCD_Clear(void);
void LCD_Init(void);
void LCD_Cursor(uint8_t x, uint8_t y);
void LCD_Writestr(char* str);

#endif /* INC_LCD1602A_I2C_H_ */
