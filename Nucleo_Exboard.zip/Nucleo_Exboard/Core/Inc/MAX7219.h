/*
 * MAX7219.h
 *
 *  Created on: Nov 12, 2026
 *      Author: YOBRO
 */

#ifndef INC_MAX7219_H_
#define INC_MAX7219_H_

#include "stm32l0xx_hal.h"

#define MAX7219_CS(x) HAL_GPIO_WritePin(MAX7219_CS_GPIO_Port, MAX7219_CS_Pin, x ? 1 : 0)

#define MAX7219_CHAR_MINUS 0x0A		// '-'
#define MAX7219_CHAR_E 	   0x0B		// 'E'
#define MAX7219_CHAR_H     0x0C		// 'H'
#define MAX7219_CHAR_L     0x0D		// 'L'
#define MAX7219_CHAR_P     0x0E		// 'P'

void MAX7219_Send_Reg(uint8_t reg, uint8_t data);
void MAX7219_Clear(void);
void MAX7219_Init(void);
void MAX7219_Setlight(uint8_t light);
void MAX7219_Send_Digit(uint8_t index, uint8_t num, _Bool dot);
void MAX7219_SendBlank(uint8_t index);

#endif /* INC_MAX7219_H_ */
