/*
 * OLED.h
 *
 *  Created on: Nov 6, 2026
 *      Author: YOBRO
 */

/* --- OLED Use SSD1306 ---*/
#ifndef INC_OLED_H_
#define INC_OLED_H_

#include "stm32l0xx_hal.h"

#define OLED_ADDRESS   0x78 //0x3C << 1
#define OLED_WIDTH  128
#define OLED_HEIGHT 64

typedef struct {
    uint8_t CurrentX;
    uint8_t CurrentY;
} OLED_Current;

typedef enum {
	Black = 0,   // Set Black color
    White = 1
} OLED_COLOR;

void OLED_Send_cmd(uint8_t cmd);
void OLED_ON_OFF(uint8_t Display_Power);
void OLED_Clear(void);
void OLED_Init(void);
void OLED_Updata(void);
void OLED_Forall(OLED_COLOR color);
void OLED_Cursor(uint8_t x,uint8_t y);
void OLED_WriteDot(uint8_t x,uint8_t y,OLED_COLOR color);
void OLED_WriteChar(char ascii,OLED_COLOR color);
void OLED_Writestr(char* str,OLED_COLOR color);

#endif /* INC_OLED_H_ */
