/*
 * WS2812.h
 *
 *  Created on: Nov 11, 2026
 *      Author: YOBRO
 */

#ifndef INC_WS2812_H_
#define INC_WS2812_H_

#include "stm32l0xx_hal.h"

#define WS2812_NUMBER 7
#define WS2812_RESET 50
#define WS2812_PWM1 25
#define WS2812_PWM0 12

void WS2812_SetPixel(uint8_t index, uint8_t r, uint8_t g, uint8_t b);
void WS2812_Clear(void);
void WS2812_Show(void);
void WS2812_Init(void);

#endif /* INC_WS2812_H_ */
