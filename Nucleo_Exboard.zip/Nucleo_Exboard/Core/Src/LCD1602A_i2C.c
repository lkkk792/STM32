/*
 * LCD1602A_i2C.c
 *
 *  Created on: Nov 11, 2026
 *      Author: YOBRO
 */
#include "LCD1602A_i2C.h"

extern I2C_HandleTypeDef hi2c1;

void Delay_us(uint32_t us){
	while(us--){
		for(volatile uint8_t i=0; i < 32; i++) __NOP();
	}
}

void LCD_Send_4bits(uint8_t data, uint8_t rs){
	uint8_t buf;
	buf = (data & 0xF0) | rs | LCD_BACKLIGHT | LCD_ENABLE;
	HAL_I2C_Master_Transmit(&hi2c1, LCD_ADDRESS, &buf, 1, 10);
	Delay_us(50);
	buf = (data & 0xF0) | rs | LCD_BACKLIGHT ;
	HAL_I2C_Master_Transmit(&hi2c1, LCD_ADDRESS, &buf, 1, 10);
	Delay_us(50);
}

void LCD_Send_cmd(uint8_t cmd){
	LCD_Send_4bits(cmd & 0xF0, 0x00);			// Send High 4bit
	LCD_Send_4bits( (cmd << 4) & 0xF0, 0x00);	// Send Low  4bit
}

void LCD_Send_data(uint8_t data){
	LCD_Send_4bits(data & 0xF0, 0x01);			// Send High 4bit
	LCD_Send_4bits( (data << 4) & 0xF0, 0x01);	// Send Low  4bit
}

void LCD_Clear(void){
	LCD_Send_cmd(0x01);
	HAL_Delay(5);
}

void LCD_Init(void){
	HAL_Delay(40);				 				// Wait Voltage UP

	LCD_Send_4bits(0x30, 0x00);	 				// Switch 8bit Mode
	HAL_Delay(5);
	LCD_Send_4bits(0x30, 0x00);
	HAL_Delay(5);
	LCD_Send_4bits(0x30, 0x00);
	HAL_Delay(5);

	LCD_Send_4bits(0x20, 0x00);  				// Switch 4bit Mode
	HAL_Delay(5);

	LCD_Send_cmd(0x28);							// 4bit two Display
	HAL_Delay(5);

	LCD_Send_cmd(0x0C);							// Open Display, OFF Cursor Display
	HAL_Delay(5);

	LCD_Send_cmd(0x06);							// Input Mode Cursor Auto move right
	HAL_Delay(5);

	LCD_Clear();
}

void LCD_Cursor(uint8_t x, uint8_t y){			// x:0~15, y:0~1
	LCD_Send_cmd((uint8_t) (y == 0) ? (0x80 + x) : (0xC0 + x)) ;
}

void LCD_Writestr(char* str){
	while(*str){
		LCD_Send_data((uint8_t) (*str++));
	}
}
