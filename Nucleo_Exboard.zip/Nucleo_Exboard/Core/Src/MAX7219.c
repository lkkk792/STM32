/*
 * MAX7219.c
 *
 *  Created on: Nov 12, 2026
 *      Author: YOBRO
 */
#include "MAX7219.h"

extern SPI_HandleTypeDef hspi2;

void MAX7219_Send_Reg(uint8_t reg, uint8_t data){
	uint8_t buf[2] = {reg , data};
	GPIOA->BRR = 1 << 8;					// MAX7219_CS(0)
	HAL_SPI_Transmit(&hspi2, buf, 2, 10);
	GPIOA->BSRR = 1 << 8;					// MAX7219_CS(1)
}

void MAX7219_Clear(void){
	for(uint8_t i=1; i <= 8; i++){
		MAX7219_Send_Reg(i, 0x0F);			// Blank
 	}
}

void MAX7219_Init(void){
	GPIOA->BSRR = 1 << 8;					// MAX7219_CS(1)

	MAX7219_Send_Reg(0x0F, 0x00);			// OFF TEST Mode
	MAX7219_Send_Reg(0x09, 0xFF);			// Decode
	MAX7219_Send_Reg(0x0B, 0x07);			// Scan 8bit
	MAX7219_Send_Reg(0x0A, 0x01);			// light:0~15
	MAX7219_Send_Reg(0x0C, 0x01);			// Normal Display Mode

	MAX7219_Clear();

	for(uint8_t i=1; i <= 8; i++){
		MAX7219_Send_Reg(i, MAX7219_CHAR_MINUS);
	}
}

void MAX7219_Setlight(uint8_t light){
	if(light > 0x0F) light = 0x0F;
	MAX7219_Send_Reg(0x0A, light);
}

void MAX7219_Send_Digit(uint8_t index, uint8_t num, _Bool dot){
	if(index > 8 || index < 1) return;
	if(dot) num |= 0x80;
	MAX7219_Send_Reg(index, num);
}

void MAX7219_SendBlank(uint8_t index){
	MAX7219_Send_Reg(index, 0x0F);
}
