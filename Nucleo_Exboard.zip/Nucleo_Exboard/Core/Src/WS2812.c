/*
 * WS2812.c
 *
 *  Created on: Nov 11, 2026
 *      Author: YOBRO
 */
#include "WS2812.h"
#include <string.h>

extern TIM_HandleTypeDef htim2;

static uint8_t WS2812_Buf[WS2812_NUMBER * 24 + WS2812_RESET];
static volatile _Bool WS2812_dma_flag = 0;

void WS2812_SetPixel(uint8_t index, uint8_t r, uint8_t g, uint8_t b){
	uint32_t grb = ((uint32_t)g << 16) | ((uint32_t)r << 8) | b;

	for(uint8_t i=0; i < 24; i++){
		if(grb & (0x00800000 >> i)){
			WS2812_Buf[index*24 + i] = WS2812_PWM1;
		}
		else{
			WS2812_Buf[index*24 + i] = WS2812_PWM0;
		}
	}
}

void WS2812_Clear(void){
	for(uint8_t i=0; i < WS2812_NUMBER; i++){
		WS2812_SetPixel(i, 0, 0, 0);
	}
}

void WS2812_Show(void){
	if(WS2812_dma_flag) return;
	memset(&WS2812_Buf[WS2812_NUMBER * 24], 0, WS2812_RESET);
	WS2812_dma_flag = 1;
	HAL_TIM_PWM_Start_DMA(&htim2, TIM_CHANNEL_1, (uint32_t *)WS2812_Buf, WS2812_NUMBER * 24 + WS2812_RESET);
}

void WS2812_Init(void){
	memset(WS2812_Buf, 0, sizeof(WS2812_Buf));
	WS2812_Clear();
	WS2812_Show();
}

void HAL_TIM_PWM_PulseFinishedCallback(TIM_HandleTypeDef *htim){
	if(htim == &htim2){
		HAL_TIM_PWM_Stop_DMA(&htim2, TIM_CHANNEL_1);
		WS2812_dma_flag = 0;
	}
}
