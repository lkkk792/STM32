/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "dma.h"
#include "i2c.h"
#include "rtc.h"
#include "spi.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <string.h>
#include "WS2812.h"
#include "LCD1602A_i2C.h"
#include "OLED.h"
#include "MAX7219.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define KEY1 HAL_GPIO_ReadPin(KEY1_GPIO_Port, KEY1_Pin)				   			// KEY:Press = 0, KEY:Open = 1

#define LED5(x) HAL_GPIO_WritePin(LED5_GPIO_Port, LED5_Pin, x ? 1 : 0) 			// PB3 ->LED5
#define LED4(x) HAL_GPIO_WritePin(LED4_GPIO_Port, LED4_Pin, x ? 1 : 0) 			// PB4 ->LED4
#define LED3(x) HAL_GPIO_WritePin(LED3_GPIO_Port, LED3_Pin, x ? 1 : 0) 			// PB5 ->LED3
																	   	   	    // PB14->LED2

#define LED1_R(x) HAL_GPIO_WritePin(LED1_R_GPIO_Port, LED1_R_Pin, x ? 1 : 0)
#define LED1_G(x) HAL_GPIO_WritePin(LED1_G_GPIO_Port, LED1_G_Pin, x ? 1 : 0)
#define LED1_B(x) HAL_GPIO_WritePin(LED1_B_GPIO_Port, LED1_B_Pin, x ? 1 : 0)

#define BZ(x) HAL_GPIO_WritePin(BUZZER_GPIO_Port, BUZZER_Pin, x ? 1 : 0)		// 2.7kHz

#define	SPI2_STCP(x) HAL_GPIO_WritePin(SPI2_STCP_GPIO_Port, SPI2_STCP_Pin, x ? 1 : 0)
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* ---------- RTC Private variables ---------- */
RTC_TimeTypeDef sTime;
RTC_DateTypeDef sDate;

/* ---------- 74HC595 LED SPI Control and LED PWM Private variables ---------- */
uint32_t LED595_time = 0;
uint8_t LED_index;

uint32_t PWM_time = 0;
uint16_t PWM_Duty = 0;
int8_t k = 10;

/* ---------- OLED SSD1306 Display and MAX7219 RTC Clock Private variables ---------- */
uint32_t time_cnt = 0, Display_cnt = 0;
char OLED_buf[30];

/* ---------- LCD LCD1602A DisplayPrivate variables ---------- */
char LCD_buf[20];

/* ---------- KEY1 State Private variables ---------- */
uint8_t KEY_cnt = 0;
uint8_t KEY_cnt_b = 0;
_Bool KEY1_state = 1;

/* ---------- Buzzer Control Private variables ---------- */
uint32_t BZ_time;
_Bool BZ_flag = 0;

/* ---------- SG90 Control Private variables ---------- */
int SG90_deg = 0 , SG90_deg_b = 0;
uint8_t SG90_Duty, SG90_cnt = 0;

/* ---------- ADC Read Private variables ---------- */
uint32_t adc;
uint16_t adc_val;

/* ---------- UART Private variables ---------- */
uint8_t uart_tx[50] = "Welcome to Normal IO TEST Mode^_^\r\n";
uint8_t uart_rx[17];
uint8_t rx_len;
_Bool rx_flag = 0;

/* ---------- WS2812 Private variables ---------- */
uint16_t adc_read_time = 2000;	// WS2812_Blink time and ADC Read time
uint8_t WS2812_level;
uint8_t WS2812_code[12][6][3] = {
		{{  0,  0,  0},{  0,  0,  0},{  0,  0,  0},{  0,  0,  0},{  0,  0,  0},{  0,  0,  0}},
		{{  0, 35, 15},{  0,  0,  0},{  0,  0,  0},{  0,  0,  0},{  0,  0,  0},{  0,  0,  0}},
		{{  0, 55, 10},{ 10, 40,  0},{  0,  0,  0},{  0,  0,  0},{  0,  0,  0},{  0,  0,  0}},
		{{  0, 70,  5},{ 25, 65,  0},{  0,  0,  0},{  0,  0,  0},{  0,  0,  0},{  0,  0,  0}},
		{{  5, 80,  0},{ 40, 75,  0},{ 50, 45,  0},{  0,  0,  0},{  0,  0,  0},{  0,  0,  0}},
		{{ 15, 90,  0},{ 55, 80,  0},{ 85, 60,  0},{  0,  0,  0},{  0,  0,  0},{  0,  0,  0}},
		{{ 25,100,  5},{ 75, 85,  0},{110, 60,  0},{ 90, 30,  0},{  0,  0,  0},{  0,  0,  0}},
		{{ 40,105,  0},{ 95, 80,  0},{130, 55,  0},{135, 30,  0},{  0,  0,  0},{  0,  0,  0}},
		{{ 60,100,  0},{115, 70,  0},{145, 45,  0},{155, 20,  0},{140,  5,  0},{  0,  0,  0}},
		{{ 85, 90,  0},{135, 60,  0},{160, 35,  0},{170, 15,  0},{180,  0,  0},{190,  0,  0}},
		{{200,  0,  0},{200,  0,  0},{200,  0,  0},{200,  0,  0},{200,  0,  0},{200,  0,  0}},
		{{130,130,160},{130,130,160},{130,130,160},{130,130,160},{130,130,160},{130,130,160}}
};
_Bool WS2812_Blink, WS2812_Blink_flag;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

void Reset_Init(void);
void LED595(uint8_t);

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_TIM6_Init();
  MX_TIM21_Init();
  MX_ADC_Init();
  MX_I2C2_Init();
  MX_I2C1_Init();
  MX_SPI2_Init();
  MX_USART1_UART_Init();
  MX_TIM2_Init();
  MX_RTC_Init();
  /* USER CODE BEGIN 2 */

  /* ------ Reset Init function ------ */
  Reset_Init();

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

	/* ---------- OLED SSD1306 Display and MAX7219 RTC Clock Code Begin ---------- */
	 if((uwTick - Display_cnt) > 100){
		  HAL_RTC_GetTime(&hrtc, &sTime, RTC_FORMAT_BIN);
		  HAL_RTC_GetDate(&hrtc, &sDate, RTC_FORMAT_BIN);

		  MAX7219_Send_Digit(8,sTime.Hours/10,0); 	MAX7219_Send_Digit(7,sTime.Hours%10,0);
		  MAX7219_Send_Digit(5,sTime.Minutes/10,0); MAX7219_Send_Digit(4,sTime.Minutes%10,0);
		  MAX7219_Send_Digit(2,sTime.Seconds/10,0); MAX7219_Send_Digit(1,sTime.Seconds%10,0);

		  OLED_Cursor(0,0);
		  OLED_Writestr(" Normal IO Test Mode",White);
		  sprintf(OLED_buf,"Date:20%02d/%2d/%2d",sDate.Year, sDate.Month, sDate.Date);
		  OLED_Cursor(0,10);
		  OLED_Writestr(OLED_buf,White);
		  sprintf(OLED_buf,"R6_Voltage:%01d.%03d V",adc_val / 1000, adc_val % 1000);
		  OLED_Cursor(0,20);
		  OLED_Writestr(OLED_buf,White);
		  sprintf(OLED_buf,(KEY1_state == 0) ? "KEY1_State: ON" : "KEY1_State:OFF");
		  OLED_Cursor(0,30);
		  OLED_Writestr(OLED_buf,White);
		  OLED_Updata();

		  WS2812_Show();

		  Display_cnt = uwTick;
	  }
	/* ---------- OLED SSD1306 Display and MAX7219 RTC Clock Code End ---------- */

	/* ---------- Buzzer Control Code Begin ---------- */
	 if(BZ_flag == 1){
		 if(uwTick - BZ_time > 100){
			 BZ(0);
			 BZ_flag = 0;
		 }
	 }
	/* ---------- Buzzer Control Code End ---------- */

	/* ---------- 74HC595 LED SPI and LED PWM Control Code Begin ---------- */
	 if(KEY1_state == 0){
		 if(uwTick - LED595_time > 50){
			 LED595(~(0x01 << LED_index));
			 LED_index = (LED_index + 1) % 8;
			 LED595_time = uwTick;
		 }

		 if(uwTick - PWM_time > 5){
			 TIM21->CCR2 = PWM_Duty;
			 PWM_Duty += k;
			 if(PWM_Duty >= 990)    k = -10;
			 else if(PWM_Duty <= 0) k = 10;
			 PWM_time = uwTick;
		 }
	 }
	/* ---------- 74HC595 LED SPI and LED PWM Control Code End ---------- */

	/* ---------- RGB LED and LED Control Code Begin ---------- */
	 if(KEY_cnt != KEY_cnt_b){
		 KEY_cnt_b = KEY_cnt;
		 switch(KEY_cnt){
			 case 0:
				 LED1_R(0); LED1_G(0); LED1_B(0);
				 LED3(0);   LED4(0);   LED5(0);
				 break;
			 case 1:
				 LED1_R(1); LED1_G(0); LED1_B(0);
				 LED3(0);   LED4(0);   LED5(1);
				 break;
			 case 2:
				 LED1_R(0); LED1_G(1); LED1_B(0);
				 LED3(0);   LED4(1);   LED5(0);
				 break;
			 case 3:
				 LED1_R(0); LED1_G(0); LED1_B(1);
				 LED3(0);   LED4(1);   LED5(1);
				 break;
			 case 4:
				 LED1_R(1); LED1_G(1); LED1_B(0);
				 LED3(1);   LED4(0);   LED5(0);
				 break;
			 case 5:
				 LED1_R(1); LED1_G(0); LED1_B(1);
				 LED3(1);   LED4(0);   LED5(1);
				 break;
			 case 6:
				 LED1_R(0); LED1_G(1); LED1_B(1);
				 LED3(1);   LED4(1);   LED5(0);
				 break;
			 default :
				 LED1_R(1); LED1_G(1); LED1_B(1);
				 LED3(1);   LED4(1);   LED5(1);
		 }
	 }
	/* ---------- RGB LED and LED Control Code End ---------- */

	/* ---------- UART and SG90 Control and LCD Display Code Begin ---------- */
	 if(rx_flag){
		 rx_flag = 0;
		 if( sscanf((char *)uart_rx, "SG90:%d", &SG90_deg) == 1){
			 if(SG90_deg < 0 || SG90_deg > 180){
				 SG90_deg = SG90_deg_b;
				 WS2812_SetPixel(6,255,0,0);
				 WS2812_Show();
				 sprintf((char *)uart_tx,"SG90_deg over 0~180\r\n");
				 HAL_UART_Transmit(&huart1, uart_tx, strlen((char *)uart_tx), 100);
			 }
			 else {
				 SG90_deg_b = SG90_deg;
				 WS2812_SetPixel(6,0,255,0);
				 WS2812_Show();
				 sprintf((char *)uart_tx,"SG90_deg OK! Angle\r\n");
				 HAL_UART_Transmit(&huart1, uart_tx, strlen((char *)uart_tx), 100);
			 }
		 }
		 else{
			 WS2812_SetPixel(6,255,0,0);
			 WS2812_Show();
			 sprintf((char *)uart_tx,"Transmit String not define\r\n");
			 HAL_UART_Transmit(&huart1, uart_tx, strlen((char *)uart_tx), 100);
		 }
		 sprintf(LCD_buf, "%-16s", (char *)uart_rx);
		 LCD_Cursor(0,0);
		 LCD_Writestr(LCD_buf);
	 }
	/* ---------- UART and SG90 Control and LCD Display Code End ---------- */

  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI|RCC_OSCILLATORTYPE_LSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.LSIState = RCC_LSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLLMUL_4;
  RCC_OscInitStruct.PLL.PLLDIV = RCC_PLLDIV_2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USART1|RCC_PERIPHCLK_I2C1
                              |RCC_PERIPHCLK_RTC;
  PeriphClkInit.Usart1ClockSelection = RCC_USART1CLKSOURCE_PCLK2;
  PeriphClkInit.I2c1ClockSelection = RCC_I2C1CLKSOURCE_PCLK1;
  PeriphClkInit.RTCClockSelection = RCC_RTCCLKSOURCE_LSI;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

void Reset_Init(void){
	uint8_t i;
	/* ------ OLED function Initialization ------ */
	OLED_Init();

	/* ------ LCD function Initialization ------ */
	LCD_Init();

	/* ------ MAX7219 function Initialization ------ */
	MAX7219_Init();

	/* ------ WS2812 function Initialization ------ */
	WS2812_Init();
	Delay_us(200);
	WS2812_SetPixel(6,0,0,255);
	WS2812_Show();

	/* ------ TIM21 PWM Mode Start Initialization ------ */
	HAL_TIM_PWM_Start(&htim21, TIM_CHANNEL_2);
	TIM21->CCR2 = 0;							// Duty cycle = 0%

	/* ------ Initialization Screen Code Begin ------ */
	LED3(1); LED4(1); LED5(1);
	BZ(1);
	for(i=0; i < 100; i++){
		TIM21->CCR2 = i * 10;
		LED595(i);
		if(i >= 60)LED1_R(1);
		else if(i >= 30)LED1_G(1);
		else LED1_B(1);
		HAL_Delay(9);
	}
	for(i=99; i > 0; i--){
		TIM21->CCR2 = i * 10;
		LED595(i);
		if(i >= 60)LED1_B(0);
		else if(i >= 30)LED1_G(0);
		else LED1_R(0);
		HAL_Delay(9);
	}
	BZ(0);
	TIM21->CCR2 = 0;
	LED3(0); LED4(0); LED5(0);
	/* ------ Initialization Screen Code End ------ */

	/* ------ UART Tx Rx Code Begin ------ */
	HAL_UART_Transmit(&huart1, uart_tx, sizeof(uart_tx) - 1, 100);
	HAL_UARTEx_ReceiveToIdle_IT(&huart1, uart_rx, 16);
	/* ------ UART Tx Rx Code End ------ */

	/* ------ TIM6 Base Start Initialization ------ */
	HAL_TIM_Base_Start_IT(&htim6);
}

void LED595(uint8_t data){
	GPIOB->BRR = 1 << 12;						// SPI2_STCP(0);
	HAL_SPI_Transmit(&hspi2, &data, 1, 10);
	GPIOB->BSRR = 1 << 12;						// SPI2_STCP(1);
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim){
	if(htim == &htim6){
		/* ------ SG90 Control Code Begin ------ */
		SG90_Duty = 5 + (SG90_deg * 2 + 9) / 18;
		if(SG90_cnt < SG90_Duty) GPIOB->BSRR = 0x4;
		else GPIOB->BRR = 0x4;
		SG90_cnt = SG90_cnt + 1 % 200;
		/* ------ SG90 Control Code Eed ------ */
		/* ------ KEY1 Read Code Begin ------ */
		if((KEY1 == 0) && (KEY1_state == 1)){
			BZ_flag = 1; BZ_time = uwTick; BZ(1);
			KEY_cnt = (KEY_cnt + 1) % 8;
			KEY1_state = 0;
		}
		else if((KEY1 == 1) && (KEY1_state == 0)){
			LED595(0x00);
			TIM21->CCR2 = 0;
			WS2812_SetPixel(6,0,0,0);
			WS2812_Show();
			KEY1_state = 1;
		}
		/* ------ KEY1 Read Code End ------ */
		/* ------ ADC Read Code Begin ------ */
		if(time_cnt > adc_read_time){
			HAL_ADCEx_Calibration_Start(&hadc, ADC_SINGLE_ENDED);
			HAL_ADC_Start_DMA(&hadc,(uint32_t *) &adc, 1);
			time_cnt = 0;
		}
		time_cnt++;
		/* ------ ADC Read Code End ------ */
	}
}

void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc){
	/* ------ ADC_Value Conversion ------ */
	adc_val = adc * 3300 / 4095;

	/* ------ WS2812 Code Begin ------ */
	if(adc_val <= 275) 		 WS2812_level = 0;
	else if(adc_val <= 550)  WS2812_level = 1;
	else if(adc_val <= 825)  WS2812_level = 2;
	else if(adc_val <= 1100) WS2812_level = 3;
	else if(adc_val <= 1375) WS2812_level = 4;
	else if(adc_val <= 1650) WS2812_level = 5;
	else if(adc_val <= 1925) WS2812_level = 6;
	else if(adc_val <= 2200) WS2812_level = 7;
	else if(adc_val <= 2475) WS2812_level = 8;
	else if(adc_val <= 2750) WS2812_level = 9;
	else if(adc_val <= 3025) WS2812_level = 10;
	else if(adc_val <= 3300) WS2812_level = 11;

	for(uint8_t i=0; i < 6; i++){
		if(WS2812_Blink_flag){
			WS2812_SetPixel(i,WS2812_code[WS2812_level][i][0],WS2812_code[WS2812_level][i][1],WS2812_code[WS2812_level][i][2]);
		}
		else {
			WS2812_SetPixel(i,0,0,0);
		}
	}

	if(WS2812_level < 10) {
		WS2812_Blink = 0;
		WS2812_Blink_flag = 1;
		adc_read_time = 2000;
	}
	else {
		WS2812_Blink = 1;
		if(WS2812_level == 11) adc_read_time = 1000;
		else adc_read_time = 2000;
	}

	if(WS2812_Blink){
		if(WS2812_Blink_flag){
			WS2812_Show();
			WS2812_Blink_flag = 0;
		}
		else{
			WS2812_Show();
			WS2812_Blink_flag = 1;
		}
	}
	else WS2812_Show();
	/* ------ WS2812 Code End ------ */

}

void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size){
	/* ------ UART Read Idle Callback ------ */
	if(huart == &huart1){
		rx_len = Size;
		rx_flag = 1;
		uart_rx[rx_len] = '\0';
		HAL_UARTEx_ReceiveToIdle_IT(&huart1, uart_rx, 16);
	}
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
